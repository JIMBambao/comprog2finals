package edu.slu.prog2;

public class employee {
}
